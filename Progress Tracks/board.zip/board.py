import random

class Checkers:
    def __init__(self):
        self.board = [[' ' for _ in range(8)] for _ in range(8)]
        self.initialize_board()
        self.mandatory_capture = False

    def initialize_board(self):
        for row in range(3):
            for col in range(8):
                if (row + col) % 2 == 1:
                    self.board[row][col] = 'c'

        for row in range(5, 8):
            for col in range(8):
                if (row + col) % 2 == 1:
                    self.board[row][col] = 'p'

    def print_board(self, available_moves=None):
    
        print(" ", end=" ")
        for col in range(8):
            print(f" {col} ", end=" ")
        print()
        print(" +---+---+---+---+---+---+---+---+")

        

        for row in range(8):
            print(row, end="|")
            for col in range(8):
                piece = self.board[row][col]
                
                if available_moves and (row, col) in available_moves:
                    print(" * |", end="")
                elif piece == 'p':
                    print(" p |", end="")
                elif piece == 'c':
                    print(" c |", end="")
                elif piece == 'P':
                    print(" P |", end="")
                elif piece == 'C':
                    print(" C |", end="")
                else:
                    print("   |", end="")
                # if piece == 'p':
                #     piece_display = '\033[91m' + piece + '\033[0m'  # Red for player
                # elif piece == 'c':
                #     piece_display = '\033[94m' + piece + '\033[0m'  # Blue for computer
                # elif piece == 'P':
                #     piece_display = '\033[91m' + piece + '\033[0m'  # Red for player king
                # elif piece == 'C':
                #     piece_display = '\033[94m' + piece + '\033[0m'  # Blue for computer king
                # else:
                #     piece_display = piece
                # print(f" {piece_display} |", end="")
            print()
            print(" +---+---+---+---+---+---+---+---+")

    def move_piece(self, start_row, start_col, end_row, end_col, player):
        piece = self.board[start_row][start_col]
        captured_piece_pos = None  # Initialize captured piece position
        if piece.lower() != player:
            print(f"Invalid move. You can only move '{player}' pieces.")
            return False, captured_piece_pos
        if piece == ' ':
            print("No piece at starting position.")
            return False, captured_piece_pos
        if abs(start_row - end_row) != abs(start_col - end_col):
            print("Invalid move. Moves must be diagonal.")
            return False, captured_piece_pos
        if abs(start_row - end_row) > 2:
            print("Invalid move. Can only move one or two spaces.")
            return False, captured_piece_pos
        if abs(start_row - end_row) == 2:
            mid_row = (start_row + end_row) // 2
            mid_col = (start_col + end_col) // 2
            if self.board[mid_row][mid_col].lower() != ('p' if player == 'c' else 'c'):
                print("Invalid move. Must jump over opponent's piece.")
                return False, captured_piece_pos
            captured_piece_pos = (mid_row, mid_col)  # Set captured piece position
            self.board[mid_row][mid_col] = ' '
        self.board[end_row][end_col] = piece
        self.board[start_row][start_col] = ' '
        print("Valid move!")
        self.check_for_king(end_row, end_col)
        return True, captured_piece_pos  # Return captured piece position

    def check_for_king(self, row, col):
        if row == 0 and self.board[row][col] == 'p':
            self.board[row][col] = 'P'
            print("Player piece crowned as King!")
        elif row == 7 and self.board[row][col] == 'c':
            self.board[row][col] = 'C'
            print("Computer piece crowned as King!")

    def quit_game(self):
        print("Game quit by user.")
        exit()

    def surrender_and_restart(self):
        print("You have surrendered. Restarting the game...")
        self.__init__()

def main():
    game = Checkers()
    print("Welcome to Checkers!")
    print("To move a piece, enter the starting position and then the ending position.")
    print("For example: '2 1 3 2' moves a piece from row 2, col 1 to row 3, col 2.")
    print("Press 'Q' to quit the game.")
    print("Press 'S' to surrender and restart the game.")
    print("To toggle mandatory capture on/off, press 'M'.")
    input("Press Enter to start the game...")

    while True:
        game.print_board()
        start_input = input("Enter start position (row col): ").strip()
        if start_input.upper() == 'Q':
            game.quit_game()
        elif start_input.upper() == 'S':
            game.surrender_and_restart()
            continue
        elif start_input.upper() == 'M':
            game.mandatory_capture = not game.mandatory_capture
            print(f"Mandatory capture {'enabled' if game.mandatory_capture else 'disabled'}.")
            continue

        end_input = input("Enter end position (row col): ").strip()
        if len(start_input.split()) != 2 or len(end_input.split()) != 2:
            print("Invalid input. Please enter row and column separated by space.")
            continue
        try:
            start_row, start_col = map(int, start_input.split())
            end_row, end_col = map(int, end_input.split())
        except ValueError:
            print("Invalid input. Please enter integers.")
            continue
        if not (0 <= start_row < 8 and 0 <= start_col < 8 and 0 <= end_row < 8 and 0 <= end_col < 8):
            print("Invalid input. Position out of range.")
            continue

        valid_move, captured_piece_pos = game.move_piece(start_row, start_col, end_row, end_col, 'p')
        if not valid_move:
            print("Invalid move. Please try again.")
            continue
        if captured_piece_pos:
            print(f"Piece captured at position {captured_piece_pos} and removed.")

        # Check for win condition
        x_count = sum(row.count('p') + row.count('P') for row in game.board)
        o_count = sum(row.count('c') + row.count('C') for row in game.board)
        if x_count == 0:
            print("Congratulations! 'c' wins!")
            break
        elif o_count == 0:
            print("Congratulations! 'p' wins!")
            break

        # Computer's move
        available_moves = []
        for row in range(8):
            for col in range(8):
                if game.board[row][col].lower() == 'c':
                    directions = [(1, -1), (1, 1), (-1, -1), (-1, 1)] if game.board[row][col] == 'C' else [(1, -1), (1, 1)]
                    for dr, dc in directions:
                        if 0 <= row + dr < 8 and 0 <= col + dc < 8 and game.board[row + dr][col + dc] == ' ':
                            available_moves.append((row, col, row + dr, col + dc))
                        if 0 <= row + 2*dr < 8 and 0 <= col + 2*dc < 8 and game.board[row + dr][col + dc].lower() == 'p' and game.board[row + 2*dr][col + 2*dc] == ' ':
                            available_moves.append((row, col, row + 2*dr, col + 2*dc))

        if available_moves:
            capture_moves = [move for move in available_moves if abs(move[0] - move[2]) == 2]
            if capture_moves:
                comp_move = random.choice(capture_moves)
            else:
                comp_move = random.choice(available_moves)
            game.move_piece(comp_move[0], comp_move[1], comp_move[2], comp_move[3], 'c')
            if abs(comp_move[0] - comp_move[2]) == 2:
                captured_piece_row = (comp_move[0] + comp_move[2]) // 2
                captured_piece_col = (comp_move[1] + comp_move[3]) // 2
                print(f"Computer captured a piece at position ({captured_piece_row}, {captured_piece_col}) and moved from ({comp_move[0]}, {comp_move[1]}) to ({comp_move[2]}, {comp_move[3]}).")
            else:
                print(f"Computer moved from ({comp_move[0]}, {comp_move[1]}) to ({comp_move[2]}, {comp_move[3]}).")
        else:
            print("No available moves for the computer.")
            break


if __name__ == "__main__":
  
    main()